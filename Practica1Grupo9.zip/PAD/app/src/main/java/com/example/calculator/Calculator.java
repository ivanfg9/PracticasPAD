package com.example.calculator;

public class Calculator {
    public Integer add(Integer x, Integer y){
        return x+y;
    }
}
